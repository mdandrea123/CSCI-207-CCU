#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Grid and domain configuration
//#define nx 50             // Number of grid points in the x direction
//#define ny 50             // Number of grid points in the y direction
#define L_X 30.0           // Length of the domain in the x direction
#define L_Y 30.0           // Length of the domain in the y direction
#define GRAVITY 9.81       // Gravitational acceleration
//#define FILENAME "simulation_data.txt"  // Name of the file where data will be written
extern int nx;
extern int ny;
extern int timesteps;
extern char* FILENAME;

// function prototypes 
void initialize(double h[nx][ny], double u[nx][ny], double v[nx][ny]);
void write_to_file(const char *filename, double h[nx][ny], double u[nx][ny], double v[nx][ny], double dt, int total_timesteps, int current_timestep);
void simulate(double h[nx][ny], double u[nx][ny], double v[nx][ny], double dt);